// const calculator = {
//   plus: function(a, b){
//     return a + b;
//   },
//   minus: function(a, b){
//     return a - b;
//   },
//   times: function(a, b){
//     return a - b;
//   },
//   division: function(a, b){
//     return a / b;
//   },
//   power: function(a, b){
//     return a ** b;
//   },
//   remainder: function(a, b){
//     return a % b;
//   },
// }

// const rPlus = calculator.plus(1, 2)
// const rMinus = calculator.minus(8, 2)
// const rTimes = calculator.times(4, 2)
// const rDivision = calculator.division(6, 2)
// const rPower = calculator.power(5, 2)
// const rRemainder = calculator.remainder(3, 2)

// console.log(rPlus, rMinus, rTimes, rDivision, rPower, rRemainder)

// const title = document.querySelector("#title");

// const BASE_COLOR = "#559555";

// function init(){
//   title.style.color=BASE_COLOR;
//   title.addEventListener("mouseenter", handleClick);
// }
// init();


